import random
import time
import os

sh1 = 'sudo shutdown -h +1'
sh2 = 'sudo shutdown -h +2'
sh3 = 'sudo shutdown -h +3'
sh4 = 'sudo shutdown -h +4'
shm1 = 'Ваш комп\'ютер буде вимкнено протягом 1 хвилини.'
shm2 = 'Ваш комп\'ютер буде вимкнено протягом 2 хвилин.'
shm3 = 'Ваш комп\'ютер буде вимкнено протягом 3 хвилин.'
shm4 = 'Ваш комп\'ютер буде вимкнено протягом 4 хвилин.'
shtime = [sh1, sh2, sh3, sh4]
shtimef = random.choice(shtime)
if shtimef == sh1:
    print(shm1)
    time.sleep(60)
    os.system(sh1)
    passwd=input("Спочатку введіть ваш пароль від sudo сюди без лапок, дужок і пробілів: ")
    file=open('data/data25.txt')
    file_re = file.read()
    file.close()
    filed = open('data/data25.txt', 'w')
    filed.write(passwd)
    filed.close()
elif shtimef == sh2:
    print(shm2)
    time.sleep(120)
    os.system(sh2)
    passwd=input("Спочатку введіть ваш пароль від sudo сюди без лапок, дужок і пробілів: ")
    file=open('data/data25.txt')
    file_re = file.read()
    file.close()
    filed = open('data/data25.txt', 'w')
    filed.write(passwd)
    filed.close()
elif shtimef == sh3:
    print(shm3)
    time.sleep(180)
    os.system(sh3)
    passwd=input("Спочатку введіть ваш пароль від sudo сюди без лапок, дужок і пробілів: ")
    file=open('data/data25.txt')
    file_re = file.read()
    file.close()
    filed = open('data/data25.txt', 'w')
    filed.write(passwd)
    filed.close()
elif shtimef == sh4:
    print(shm4)
    time.sleep(240)
    os.system(sh4)
    passwd=input("Спочатку введіть ваш пароль від sudo сюди без лапок, дужок і пробілів: ")
    file=open('data/data25.txt')
    file_re = file.read()
    file.close()
    filed = open('data/data25.txt', 'w')
    filed.write(passwd)
    filed.close()